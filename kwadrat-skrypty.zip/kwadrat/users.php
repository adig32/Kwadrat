<?php

require_once 'connect.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$flat_id = $_POST['flat_id'];

$sql = "SELECT users.login 
		FROM users, messages, flats 
		WHERE messages.flat_id='$flat_id' 
		AND messages.user_from=users.id 
		AND messages.user_from!=flats.user_id 
		AND flats.id=messages.flat_id 
		GROUP BY users.login";
		
$result = $conn->query($sql);

$users = array();

if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
        
		$users[] = $row;
		
    }
} else {
    echo "0 results";
}

$users = mb_convert_encoding($users, 'UTF-8', 'UTF-8');

$json = json_encode($users);

if($json)
	echo $json;
else
	echo json_last_error_msg();

$conn->close();
?>