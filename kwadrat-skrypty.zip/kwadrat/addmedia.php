<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

	$media = $_POST['media'];
	$email = $_POST['email'];

    require_once 'connect.php';

	$sql = "INSERT INTO flat_media (flat_id, 
			media_id) VALUES 
			((SELECT id FROM flats WHERE user_id=(SELECT id FROM users WHERE email='$email') ORDER BY updated_at DESC LIMIT 1), 
			(SELECT id FROM media WHERE media_name='$media'));";

    if ( mysqli_query($conn, $sql) ) {
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($conn);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";

        echo json_encode($result);
        mysqli_close($conn);
    }
}

?>