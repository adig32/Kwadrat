<?php

require_once 'connect.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$city_name = $_POST['city_name'];

$sql = "SELECT * FROM districts WHERE city_id=(SELECT id FROM cities WHERE city_name='$city_name')";
$result = $conn->query($sql);

$districts = array();

if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
        
		$districts[] = $row;
		
    }
} else {
    echo "0 results";
}

$districts = mb_convert_encoding($districts, 'UTF-8', 'UTF-8');

$json = json_encode($districts);

if($json)
	echo $json;
else
	echo json_last_error_msg();

$conn->close();
?>