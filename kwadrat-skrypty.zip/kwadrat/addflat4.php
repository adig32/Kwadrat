<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

	$inconveniences = $_POST['inconveniences'];
	$email = $_POST['email'];

    require_once 'connect.php';

	$sql = "INSERT INTO inconveniences (flat_id, 
			inconvenience_description) VALUES 
			((SELECT id FROM flats WHERE user_id=(SELECT id FROM users WHERE email='$email') ORDER BY updated_at DESC LIMIT 1), 
			'$inconveniences');";

    if ( mysqli_query($conn, $sql) ) {
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($conn);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";

        echo json_encode($result);
        mysqli_close($conn);
    }
}

?>