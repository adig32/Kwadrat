<?php 
 	
	require_once 'connect.php';
	
	if (mysqli_connect_errno()) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die();
	}
	
	$email = $_POST['email'];
	
	$stmt = $conn->prepare("SELECT rental_histories.flat_id, cities.city_name, flats.street, districts.district_name, rental_histories.user_id, flats.user_id AS owner_id
							FROM flats, cities, districts, rental_histories, users
							WHERE rental_histories.flat_id=flats.id
							AND rental_histories.user_id=(SELECT id FROM users WHERE email='$email')
							AND flats.city_id=cities.id
							AND flats.district_id=districts.id
							GROUP BY rental_histories.flat_id;");
	
	$stmt->execute();
	
	$stmt->bind_result($flat_id, $city_name, $street, $district_name, $user_id, $owner_id);
	
	$flats = array(); 
	
	while($stmt->fetch()){
		$temp = array();
		$temp['flat_id'] = $flat_id;
		$temp['city_name'] = $city_name;
		$temp['street'] = $street;
		$temp['district_name'] = $district_name;
		$temp['user_id'] = $user_id;
		$temp['owner_id'] = $owner_id;
		array_push($flats, $temp);
	}
	
	echo json_encode($flats);
	
?>