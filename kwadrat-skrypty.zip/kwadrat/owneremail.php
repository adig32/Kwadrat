<?php

if ($_SERVER['REQUEST_METHOD']=='POST') {

    $flat_id = $_POST['flat_id'];

    require_once 'connect.php';

    $sql = "SELECT users.email FROM users, flats WHERE flats.id='$flat_id' AND users.id=flats.user_id";

    $response = mysqli_query($conn, $sql);

    $result = array();
    $result['profile'] = array();
    
    if ( mysqli_num_rows($response) == 1 ) {
        
        $row = mysqli_fetch_assoc($response);

        if ( mysqli_query($conn, $sql) ) {
            
            $index['email'] = $row['email'];

            array_push($result['profile'], $index);

            $result['success'] = "1";
            $result['message'] = "success";
            
			echo json_encode($result);
            mysqli_close($conn);

        } else {

            $result['success'] = "0";
            $result['message'] = "error";
            
			echo json_encode($result);
            mysqli_close($conn);

        }

    }

}

?>