<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

	$city_name = $_POST['city_name'];
	$district_name = $_POST['district_name'];
	$floor_number = $_POST['floor_number'];
	$number_of_floors = $_POST['number_of_floors'];
	$ground_floor_flats = $_POST['ground_floor_flats'];
	$number_of_rooms = $_POST['number_of_rooms'];
	$type_of_building = $_POST['type_of_building'];
	$heating = $_POST['heating'];
	$parking_place = $_POST['parking_place'];
	$number_of_parking_place = $_POST['number_of_parking_place'];
	$email = $_POST['email'];

    require_once 'connect.php';

    $sql = "UPDATE flats 
			SET district_id=(SELECT id FROM districts WHERE district_name='$district_name' AND city_id=(SELECT id FROM cities WHERE city_name='$city_name')), 
			floor_id=(SELECT id FROM floors WHERE floor_number='$floor_number'), 
			number_of_floors='$number_of_floors', 
			ground_floor_flats='$ground_floor_flats', 
			number_of_rooms_id=(SELECT id FROM number_of_rooms WHERE number_of_rooms='$number_of_rooms'), 
			type_of_building_id=(SELECT id FROM type_of_buildings WHERE type_of_building='$type_of_building'), 
			heating_id=(SELECT id FROM heatings WHERE type_of_heating='$heating'),
			parking_place_id=(SELECT id FROM parking_places WHERE type_of_parking_place='$parking_place'),
			number_of_parking_place='$number_of_parking_place',
			updated_at=(SELECT NOW()) WHERE id=(SELECT id FROM flats WHERE user_id=(SELECT id FROM users WHERE email='$email') ORDER BY created_at DESC LIMIT 1)";

    if ( mysqli_query($conn, $sql) ) {
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($conn);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";

        echo json_encode($result);
        mysqli_close($conn);
    }
}

?>