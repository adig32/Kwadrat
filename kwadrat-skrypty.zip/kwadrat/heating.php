<?php

require_once 'connect.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM heatings WHERE id>1;";
$result = $conn->query($sql);

$heatings = array();

if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
        
		$heatings[] = $row;
		
    }
} else {
    echo "0 results";
}

$heatings = mb_convert_encoding($heatings, 'UTF-8', 'UTF-8');

$json = json_encode($heatings);

if($json)
	echo $json;
else
	echo json_last_error_msg();

$conn->close();
?>