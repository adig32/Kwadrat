<?php
    $id = $_POST['id'];

    require_once 'connect.php';

    $sql = "SELECT AVG(number_of_stars) AS note FROM reviews, flats WHERE reviews.flat_id='$id' AND flats.user_id=reviews.user_about";

    $response = mysqli_query($conn, $sql);

    $result = array();
    $result['note'] = array();
    
    if ( mysqli_num_rows($response) == 1 ) {
        
        $row = mysqli_fetch_assoc($response);

        if ( mysqli_query($conn, $sql) ) {
            
            $index['note'] = $row['note'];

            array_push($result['note'], $index);

            $result['success'] = "1";
            $result['message'] = "success";
            
			echo json_encode($result);
            mysqli_close($conn);

        } else {

            $result['success'] = "0";
            $result['message'] = "error";
            
			echo json_encode($result);
            mysqli_close($conn);

        }

    }
?>