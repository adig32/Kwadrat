<?php

if ($_SERVER['REQUEST_METHOD']=='POST') {

    $email = $_POST['email'];

    require_once 'connect.php';

    $sql = "SELECT * FROM users WHERE email='$email' ";

    $response = mysqli_query($conn, $sql);

    $result = array();
    $result['profile'] = array();
    
    if ( mysqli_num_rows($response) == 1 ) {
        
        $row = mysqli_fetch_assoc($response);

        if ( mysqli_query($conn, $sql) ) {
            
            $index['id'] = $row['id'];
            $index['name'] = $row['name'];
			$index['second_name'] = $row['second_name'];
			$index['last_name'] = $row['last_name'];
			$index['birth_date'] = $row['birth_date'];
			$index['place'] = $row['place'];
			$index['postcode'] = $row['postcode'];
			$index['login'] = $row['login'];
			$index['gender'] = $row['gender'];
			$index['phone_number'] = $row['phone_number'];
            $index['email'] = $row['email'];

            array_push($result['profile'], $index);

            $result['success'] = "1";
            $result['message'] = "success";
            
			echo json_encode($result);
            mysqli_close($conn);

        } else {

            $result['success'] = "0";
            $result['message'] = "error";
            
			echo json_encode($result);
            mysqli_close($conn);

        }

    }

}

?>