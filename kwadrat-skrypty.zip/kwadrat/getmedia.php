<?php 
 
	require_once 'connect.php';
	
	if (mysqli_connect_errno()) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die();
	}
	
	$id = $_POST['id'];
	
	$stmt = $conn->prepare("SELECT media.media_name FROM media, flats, flat_media WHERE flats.id='$id' AND flat_media.flat_id=flats.id AND flat_media.media_id=media.id;");
	
	$stmt->execute();
	
	$stmt->bind_result($media_name);
	
	$equipment = array(); 
	
	while($stmt->fetch()){
		$temp = array();
		$temp['media_name'] = $media_name;
		array_push($equipment, $temp);
	}
	
	echo json_encode($equipment);
	
?>