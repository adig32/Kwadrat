<?php

require_once 'connect.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM cities";
$result = $conn->query($sql);

$cities = array();

if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
        
		$cities[] = $row;
		
    }
} else {
    echo "0 results";
}

$cities = mb_convert_encoding($cities, 'UTF-8', 'UTF-8');

$json = json_encode($cities);

if($json)
	echo $json;
else
	echo json_last_error_msg();

$conn->close();
?>