<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

    $email = $_POST['email'];
    $city_name = $_POST['city_name'];
    $street = $_POST['street'];
    $flat_area = $_POST['flat_area'];
	$number_of_tenants = $_POST['number_of_tenants'];
    $rent = $_POST['rent'];
    $additional_fees = $_POST['additional_fees'];
	$deposit = $_POST['deposit'];
    $media_fees = $_POST['media_fees'];

    require_once 'connect.php';

	$sql = "INSERT INTO flats (user_id,
			street,
			city_id,
            flat_area,
            number_of_tenants,
            rent,
            additional_fees,
            deposit,
            media_fees,
			visibility,
			created_at,
			blocked) 
			VALUES ((SELECT id FROM users WHERE email='$email'),
			'$street',
			(SELECT id FROM cities WHERE city_name='$city_name'),
            '$flat_area',
            '$number_of_tenants',
            '$rent',
            '$additional_fees',
            '$deposit',
            '$media_fees',
			1,
			(SELECT NOW()),
			0)";


    if ( mysqli_query($conn, $sql) ) {
		
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($conn);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";

        echo json_encode($result);
        mysqli_close($conn);
    }
}

?>