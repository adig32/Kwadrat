<?php

if ($_SERVER['REQUEST_METHOD']=='POST') {

    $email = $_POST['email'];

    require_once 'connect.php';

    $sql = "SELECT path FROM photos WHERE flat_id=(SELECT id FROM flats WHERE user_id=(SELECT id FROM users WHERE email='$email') ORDER BY id DESC LIMIT 1) ORDER BY id DESC LIMIT 1;";

    $response = mysqli_query($conn, $sql);

    $result = array();
    $result['setimage'] = array();
    
    if ( mysqli_num_rows($response) == 1 ) {
        
        $row = mysqli_fetch_assoc($response);

        if ( mysqli_query($conn, $sql) ) {
            
            $index['path'] = $row['path'];

            array_push($result['setimage'], $index);

            $result['success'] = "1";
            $result['message'] = "success";
            
			echo json_encode($result);
            mysqli_close($conn);

        } else {

            $result['success'] = "0";
            $result['message'] = "error";
            
			echo json_encode($result);
            mysqli_close($conn);

        }

    }

}

?>