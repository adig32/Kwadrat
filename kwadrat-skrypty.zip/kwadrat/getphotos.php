<?php 
 
	require_once 'connect.php';
	
	if (mysqli_connect_errno()) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die();
	}
	
	$id = $_POST['id'];
	
	$stmt = $conn->prepare("SELECT photos.path FROM photos, flats WHERE flats.id='$id' AND photos.flat_id=flats.id;");
	
	$stmt->execute();
	
	$stmt->bind_result($path);
	
	$photos = array(); 
	
	while($stmt->fetch()){
		$temp = array();
		$temp['path'] = $path;
		array_push($photos, $temp);
	}
	 
	echo json_encode($photos);
	
?>