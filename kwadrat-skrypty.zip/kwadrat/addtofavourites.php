<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

    $id = $_POST['id'];
	$email = $_POST['email'];

    require_once 'connect.php';

    $sql = "INSERT INTO 
			flat_user 
			(flat_id, 
			user_id) 
			VALUES 
			('$id', 
			(SELECT id FROM users WHERE email='$email'))";

    if ( mysqli_query($conn, $sql) ) {
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($conn);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";

        echo json_encode($result);
        mysqli_close($conn);
    }
}

?>