<?php

require_once 'connect.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM parking_places WHERE id>1;";
$result = $conn->query($sql);

$parking_places = array();

if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
        
		$parking_places[] = $row;
		
    }
} else {
    echo "0 results";
}

$parking_places = mb_convert_encoding($parking_places, 'UTF-8', 'UTF-8');

$json = json_encode($parking_places);

if($json)
	echo $json;
else
	echo json_last_error_msg();

$conn->close();
?>