<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

    $flat_id = $_POST['flat_id'];
	$user_from_email = $_POST['user_from_email'];
	$user_to_login = $_POST['user_to_login'];
	$message = $_POST['message'];

    require_once 'connect.php';

    $sql = "INSERT INTO messages 
			(flat_id, user_to, user_from, content_of_message, created_at) 
			VALUES 
			('$flat_id', (SELECT id FROM users WHERE login='$user_to_login'), (SELECT id FROM users WHERE email='$user_from_email'), '$message', (SELECT NOW()))";

    if ( mysqli_query($conn, $sql) ) {
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($conn);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";

        echo json_encode($result);
        mysqli_close($conn);
    }
}

?>