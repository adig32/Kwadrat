<?php 
 	
	require_once 'connect.php';
	
	if (mysqli_connect_errno()) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die();
	}
	
	$email = $_POST['email'];
	
	$stmt = $conn->prepare("SELECT flats.id, flats.street, cities.city_name, districts.district_name, flats.flat_area, flats.rent, flats.visibility, flats.blocked, photos.path 
							FROM flats, cities, districts, photos
							WHERE flats.user_id=(SELECT users.id FROM users WHERE users.email='$email') 
							AND flats.city_id=cities.id AND flats.district_id=districts.id
							AND photos.flat_id=flats.id GROUP BY flats.id;");
	
	$stmt->execute();
	
	$stmt->bind_result($id, $street, $city_name, $district_name, $flat_area, $rent, $visibility, $blocked, $path);
	
	$flats = array(); 
	
	while($stmt->fetch()){
		$temp = array();
		$temp['id'] = $id;
		$temp['street'] = $street;
		$temp['city_name'] = $city_name;
		$temp['district_name'] = $district_name;
		$temp['flat_area'] = $flat_area;
		$temp['rent'] = $rent;
		$temp['visibility'] = $visibility;
		$temp['blocked'] = $blocked;
		$temp['path'] = $path;
		array_push($flats, $temp);
	}
	
	echo json_encode($flats);
	
?>