<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

	$id = $_POST['id'];
    $name = $_POST['name'];
    $second_name = $_POST['second_name'];
    $last_name = $_POST['last_name'];
    $place = $_POST['place'];
    $postcode = $_POST['postcode'];
    $phone_number = $_POST['phone_number'];
	$email = $_POST['email'];

    require_once 'connect.php';

    $sql = "UPDATE users SET name='$name', second_name='$second_name', last_name='$last_name', place='$place', postcode='$postcode', phone_number='$phone_number', email='$email', updated_at=(SELECT NOW()) WHERE id=$id";

    if ( mysqli_query($conn, $sql) ) {
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($conn);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";

        echo json_encode($result);
        mysqli_close($conn);
    }
}

?>