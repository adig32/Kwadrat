<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

    $name = $_POST['name'];
    $second_name = $_POST['second_name'];
    $last_name = $_POST['last_name'];
	$birth_date = $_POST['birth_date'];
    $place = $_POST['place'];
    $postcode = $_POST['postcode'];
	$login = $_POST['login'];
    $gender = $_POST['gender'];
    $phone_number = $_POST['phone_number'];
	$email = $_POST['email'];
    $password = $_POST['password'];

    $password = password_hash($password, PASSWORD_DEFAULT);

    require_once 'connect.php';

    $sql = "INSERT INTO users (name, second_name, last_name, birth_date, place, postcode, login, gender, phone_number, email, password, type_of_user, blocked, inactive, created_at) VALUES ('$name', '$second_name', '$last_name', '$birth_date', '$place', '$postcode', '$login', '$gender', '$phone_number', '$email', '$password', 1, 0, 0, (SELECT NOW()))";

    if ( mysqli_query($conn, $sql) ) {
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($conn);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";

        echo json_encode($result);
        mysqli_close($conn);
    }
}

?>