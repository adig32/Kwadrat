<?php 
 
	require_once 'connect.php';
	
	if (mysqli_connect_errno()) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die();
	}
	
	$email = $_POST['email'];
	
	$stmt = $conn->prepare("SELECT users.login,
							messages.flat_id,
							messages.content_of_message
							FROM users, messages 
							WHERE users.id=messages.user_from
							AND messages.user_to=(SELECT id FROM users WHERE email='$email')
							ORDER BY messages.created_at DESC;");
	 
	$stmt->execute();
	
	$stmt->bind_result($login, $flat_id, $content_of_message);
	
	$flats = array(); 
	
	while($stmt->fetch()){
		$temp = array();
		$temp['login'] = $login;
		$temp['flat_id'] = $flat_id;
		$temp['content_of_message'] = $content_of_message;
		array_push($flats, $temp);
	}
	
	echo json_encode($flats);
	
?>
