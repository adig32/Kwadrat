<?php 
 
	require_once 'connect.php';
	
	if (mysqli_connect_errno()) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die();
	}
	
	$id = $_POST['id'];
	
	$stmt = $conn->prepare("SELECT flat_equipment.equipment_name FROM flat_equipment, flats, flat_has WHERE flats.id='$id' AND flat_has.flat_id=flats.id AND flat_has.equipment_id=flat_equipment.id;");
	
	$stmt->execute();
	
	$stmt->bind_result($equipment_name);
	
	$equipment = array(); 
	
	while($stmt->fetch()){
		$temp = array();
		$temp['equipment_name'] = $equipment_name;
		array_push($equipment, $temp);
	}
	 
	echo json_encode($equipment);
	
?>