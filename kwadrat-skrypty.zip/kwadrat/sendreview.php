<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

    $flat_id = $_POST['flat_id'];
	$user_id = $_POST['user_id'];
	$owner_id = $_POST['owner_id'];
	$review_content = $_POST['review_content'];
	$note = $_POST['note'];

    require_once 'connect.php';

    $sql = "INSERT INTO reviews 
			(flat_id, user_about, user_from, content_of_review, number_of_stars, blocked) 
			VALUES 
			('$flat_id', '$user_id', '$owner_id', '$review_content', '$note', 0)";

    if ( mysqli_query($conn, $sql) ) {
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($conn);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";

        echo json_encode($result);
        mysqli_close($conn);
    }
}

?>