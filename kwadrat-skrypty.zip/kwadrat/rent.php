<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

    $user_login = $_POST['user_login'];
    $flat_id = $_POST['flat_id'];
    $since_when = $_POST['since_when'];
	$until_when = $_POST['until_when'];

    require_once 'connect.php';

    $sql = "INSERT INTO rental_histories 
			(user_id, flat_id, since_when, until_when, created_at) 
			VALUES 
			((SELECT id FROM users WHERE login='$user_login'), '$flat_id', '$since_when', '$until_when', (SELECT NOW()))";

    if ( mysqli_query($conn, $sql) ) {
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($conn);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";

        echo json_encode($result);
        mysqli_close($conn);
    }
}

?>