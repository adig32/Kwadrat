<?php
    $id = $_POST['id'];

    require_once 'connect.php';

    $sql = "SELECT flats.id, 
			cities.city_name, 
			flats.street, 
			districts.district_name, 
			flats.number_of_tenants, 
			flats.flat_area, 
			floors.floor_number, 
			flats.number_of_floors, 
			flats.ground_floor_flats, 
			number_of_rooms.number_of_rooms, 
			type_of_buildings.type_of_building, 
			heatings.type_of_heating,
			parking_places.type_of_parking_place,
			flats.number_of_parking_place,
			flats.rubbish,
			flats.flat_direction,
			flats.brightness_of_flat,
			flats.environment_description,
			flats.number_of_lifts,
			flats.garage,
			flats.balcony,
			flats.animals,
			flats.family_with_children,
			flats.smoking_person,
			flats.sublet_permission,
			flats.available_from,
			flats.description,
			flats.rent,
			flats.media_fees,
			flats.additional_fees,
			flats.deposit,
			users.login,
			inconveniences.inconvenience_description, 
			photos.path 
			FROM cities, flats, districts, floors, number_of_rooms, type_of_buildings, heatings, parking_places, users, photos, inconveniences  
			WHERE flats.id='$id' 
			AND cities.id=flats.city_id 
			AND districts.id=flats.district_id 
			AND floors.id=flats.floor_id 
			AND number_of_rooms.id=flats.number_of_rooms_id 
			AND type_of_buildings.id=flats.type_of_building_id 
			AND heatings.id=flats.heating_id 
			AND parking_places.id=flats.parking_place_id 
			AND users.id=flats.user_id 
			AND photos.flat_id=flats.id
			AND inconveniences.flat_id=flats.id
            ORDER BY photos.path ASC LIMIT 1";

    $response = mysqli_query($conn, $sql);

    $result = array();
    $result['offerdetails'] = array();
    
    if ( mysqli_num_rows($response) == 1 ) {
        
        $row = mysqli_fetch_assoc($response);

        if ( mysqli_query($conn, $sql) ) {
            
            $index['city_name'] = $row['city_name'];
			$index['street'] = $row['street'];
			$index['district_name'] = $row['district_name'];
			$index['number_of_tenants'] = $row['number_of_tenants'];
			$index['flat_area'] = $row['flat_area'];
			$index['floor_number'] = $row['floor_number'];
			$index['number_of_floors'] = $row['number_of_floors'];
			$index['ground_floor_flats'] = $row['ground_floor_flats'];
			$index['number_of_rooms'] = $row['number_of_rooms'];
			$index['type_of_building'] = $row['type_of_building'];
			$index['type_of_heating'] = $row['type_of_heating'];
			$index['type_of_parking_place'] = $row['type_of_parking_place'];
			$index['number_of_parking_place'] = $row['number_of_parking_place'];
			$index['rubbish'] = $row['rubbish'];
			$index['flat_direction'] = $row['flat_direction'];
			$index['brightness_of_flat'] = $row['brightness_of_flat'];
			$index['environment_description'] = $row['environment_description'];
			$index['number_of_lifts'] = $row['number_of_lifts'];
			$index['garage'] = $row['garage'];
			$index['balcony'] = $row['balcony'];
			$index['family_with_children'] = $row['family_with_children'];
			$index['smoking_person'] = $row['smoking_person'];
			$index['animals'] = $row['animals'];
			$index['sublet_permission'] = $row['sublet_permission'];
			$index['available_from'] = $row['available_from'];
			$index['description'] = $row['description'];
			$index['rent'] = $row['rent'];
			$index['media_fees'] = $row['media_fees'];
			$index['additional_fees'] = $row['additional_fees'];
			$index['deposit'] = $row['deposit'];
			$index['login'] = $row['login'];
			$index['inconvenience_description'] = $row['inconvenience_description'];
			$index['path'] = $row['path'];
			$index['id'] = $row['id'];

            array_push($result['offerdetails'], $index);

            $result['success'] = "1";
            $result['message'] = "success";
            
			echo json_encode($result);
            mysqli_close($conn);

        } else {

            $result['success'] = "0";
            $result['message'] = "error";
            
			echo json_encode($result);
            mysqli_close($conn);

        }

    }

?>