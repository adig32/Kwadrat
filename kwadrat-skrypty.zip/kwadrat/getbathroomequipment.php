<?php 
 
	require_once 'connect.php';
	
	if (mysqli_connect_errno()) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die();
	}
	
	$id = $_POST['id'];
	
	$stmt = $conn->prepare("SELECT bathroom_equipment.equipment_name FROM bathroom_equipment, flats, bathroom_has WHERE flats.id='$id' AND bathroom_has.flat_id=flats.id AND bathroom_has.equipment_id=bathroom_equipment.id;");
	
	$stmt->execute();
	
	$stmt->bind_result($equipment_name);
	
	$equipment = array(); 
	 
	while($stmt->fetch()){
		$temp = array();
		$temp['equipment_name'] = $equipment_name;
		array_push($equipment, $temp);
	}
	 
	echo json_encode($equipment);
	
?>