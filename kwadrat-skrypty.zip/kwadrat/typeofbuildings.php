<?php

require_once 'connect.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM type_of_buildings WHERE id>1;";
$result = $conn->query($sql);

$type_of_buildings = array();

if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
        
		$type_of_buildings[] = $row;
		
    }
} else {
    echo "0 results";
}

$type_of_buildings = mb_convert_encoding($type_of_buildings, 'UTF-8', 'UTF-8');

$json = json_encode($type_of_buildings);

if($json)
	echo $json;
else
	echo json_last_error_msg();

$conn->close();
?>