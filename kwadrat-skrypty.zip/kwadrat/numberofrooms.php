<?php

require_once 'connect.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM number_of_rooms WHERE id>1;";
$result = $conn->query($sql);

$number_of_rooms = array();

if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
        
		$number_of_rooms[] = $row;
		
    }
} else {
    echo "0 results";
}

$number_of_rooms = mb_convert_encoding($number_of_rooms, 'UTF-8', 'UTF-8');

$json = json_encode($number_of_rooms);

if($json)
	echo $json;
else
	echo json_last_error_msg();

$conn->close();
?>