<?php

require_once 'connect.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM floors WHERE id>1;";
$result = $conn->query($sql);

$floors = array();

if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
        
		$floors[] = $row;
		
    }
} else {
    echo "0 results";
}

$floors = mb_convert_encoding($floors, 'UTF-8', 'UTF-8');

$json = json_encode($floors);

if($json)
	echo $json;
else
	echo json_last_error_msg();

$conn->close();
?>