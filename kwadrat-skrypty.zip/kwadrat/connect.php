<?php

$conn = mysqli_connect("localhost", "root", "", "kwadrat");
$conn -> set_charset("utf8");

?>
