<?php 
 
	require_once 'connect.php';
	
	if (mysqli_connect_errno()) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die();
	}
	
	$email = $_POST['email'];

	$stmt = $conn->prepare("SELECT flats.id, 
							flats.street, 
							cities.city_name, 
							districts.district_name, 
							flats.flat_area, 
							flats.rent, 
							users.login, 
							flats.blocked, 
							flats.visibility, 
							photos.path,			
							users.id
							FROM flats, cities, districts, users, photos, flat_user 
							WHERE flats.user_id=users.id 
							AND flats.city_id=cities.id 
							AND flats.district_id=districts.id 
							AND flat_user.user_id=(SELECT id FROM users WHERE email='$email')
							AND flats.id=flat_user.flat_id
							AND photos.flat_id=flats.id 
							GROUP BY flats.id");
	
	$stmt->execute();
	 
	$stmt->bind_result($id, $street, $city_name, $district_name, $flat_area, $rent, $login, $blocked, $visibility, $path, $user_email);
	
	$flats = array(); 
	
	while($stmt->fetch()){
		$temp = array();
		$temp['id'] = $id;
		$temp['street'] = $street;
		$temp['city_name'] = $city_name;
		$temp['district_name'] = $district_name;
		$temp['flat_area'] = $flat_area;
		$temp['rent'] = $rent;
		$temp['login'] = $login;
		$temp['blocked'] = $blocked;
		$temp['visibility'] = $visibility;
		$temp['path'] = $path;
		$temp['user_email'] = $email;
		array_push($flats, $temp);
	}
	
	echo json_encode($flats);
	
?>
