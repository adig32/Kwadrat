<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

	$rubbish = $_POST['rubbish'];
	$flat_direction = $_POST['flat_direction'];
	$brightness_of_flat = $_POST['brightness_of_flat'];
	$environment_description = $_POST['environment_description'];
	$number_of_lifts  = $_POST['number_of_lifts'];
	$available_from = $_POST['available_from'];
	$description = $_POST['description'];
	$garage = $_POST['garage'];
	$balcony = $_POST['balcony'];
	$animals = $_POST['animals'];
	$family_with_children = $_POST['family_with_children'];
	$smoking_person = $_POST['smoking_person'];
	$elevator = $_POST['elevator'];
	$sublet_permission = $_POST['sublet_permission'];
	$email = $_POST['email'];

    require_once 'connect.php';

    $sql = "UPDATE flats 
			SET rubbish='$rubbish',
			flat_direction='$flat_direction',
			brightness_of_flat='$brightness_of_flat',
			environment_description='$environment_description',
			number_of_lifts='$number_of_lifts',
			available_from='$available_from',
			description='$description',
			garage='$garage',
			balcony='$balcony',
			animals='$animals',
			family_with_children='$family_with_children',
			smoking_person='$smoking_person',
			elevator='$elevator',
			sublet_permission='$sublet_permission',
			updated_at=(SELECT NOW()) WHERE id=(SELECT id FROM flats WHERE user_id=(SELECT id FROM users WHERE email='$email') ORDER BY created_at DESC LIMIT 1)";

    if ( mysqli_query($conn, $sql) ) {
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($conn);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";

        echo json_encode($result);
        mysqli_close($conn);
    }
}

?>