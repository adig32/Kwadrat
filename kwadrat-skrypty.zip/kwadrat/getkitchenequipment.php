<?php 
 
	require_once 'connect.php';
	
	if (mysqli_connect_errno()) {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		die();
	}
	
	$id = $_POST['id'];
	
	$stmt = $conn->prepare("SELECT kitchen_equipment.equipment_name FROM kitchen_equipment, flats, kitchen_has WHERE flats.id='$id' AND kitchen_has.flat_id=flats.id AND kitchen_has.equipment_id=kitchen_equipment.id;");
	
	$stmt->execute();
	 
	$stmt->bind_result($equipment_name);
	
	$equipment = array(); 
	 
	while($stmt->fetch()){
		$temp = array();
		$temp['equipment_name'] = $equipment_name;
		array_push($equipment, $temp);
	}
	
	echo json_encode($equipment);
	
?>